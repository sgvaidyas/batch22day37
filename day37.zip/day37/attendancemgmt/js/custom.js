function  start(){
    ob=[];                
           
var mystudents = document.querySelectorAll("ul li");
document.getElementById("total").innerHTML = "TOTAL NUM OF STUDENTS = "+mystudents.length;
mystudents.forEach(function(item){               
    item.onclick = function(e){
    
    this.classList.add("bg-danger");
    ob.push(this.innerText)
    set1 = new Set(ob)
    
    document.getElementById("absent").innerHTML = "No of absentees = "+ set1.size;
    // to convert set to array , compulsary var 
    var ob1 = Array.from(set1)             
    document.getElementById("mytext").innerHTML = "Absentees are = " + ob1;               
    }
});
}