function myclock()
{
    var date= new Date();
    var hh = date.getHours();
    var mm = date.getMinutes();
    var ss = date.getSeconds();

    str="PM"
    if(hh>12)
        hh=hh%12  
    else if(hh==12)
        str="PM"
    else 
        str="AM"

    hh = (hh<10) ? "0"+hh : hh;
    mm = (mm<10) ? "0"+mm : mm;
    ss = (ss<10) ? "0"+ss : ss;    

    var fulltime = hh + " : " + mm + " : " + ss + " " + str

    document.getElementById("clock").innerHTML = fulltime;

    setTimeout(myclock, 1000);
}