function fun1()
{
    firstname="Alex"
    var lastname = new String("Dsouza")

    var a = "javascriptclass"
    x = a.charAt(5)
    y = a.charAt()
    console.log("charAt a.charAt(5) = "  + x  )
    console.log("charAt a.charAt()= "  + y  )
    x = a.charCodeAt(5) 
    console.log("a.charCodeAt(5)  = " + x )

    x = a.indexOf('t')
    console.log("a.indexOf('t') = " + x)
    console.log("a.indexOf('script') = " +  a.indexOf('script'))
    console.log("a.indexOf('s',7) = " +  a.indexOf('s',7))
    console.log("a.indexOf('z') = " +  a.indexOf('z'))
    console.log("a.lastIndexOf('s') = " +  a.lastIndexOf('s'))
    
    var a="this is strange, strange things happen here"    
    console.log(a + " : " + a.replace("strange","wonderful"))

    a="apple"
    b="orange"
    console.log("concat = "+ a+b)
    console.log("concat = "+ a.concat(b))

    var a="this is strange, strange things happen here"    
    console.log('a.search("strange") = '  + a.search("strange"))

    console.log('a.search("mango") = '  + a.search("mango"))
    
    var a="this is Strange, Strange things happen here"    
    console.log('a.search("strange") = '  + a.search("strange"))
    console.log('a.search(/strange/i) = '  + a.search(/strange/i))

    a="hi this is me"
    console.log(a + " = " + a.toUpperCase())
    b="HEY WHATSUP!!!"
    console.log(b + " = " + a.toLowerCase())

    var a="this is Strange| Strange | things | happen here"    
    console.log(a)
    console.log("a.split()  =  " + a.split("|"))

    var x = a.split("|")
    console.log(typeof(x))
    for (i of x)
        console.log(i)

    var a="this is Strange Strange  things  happen here"  
    console.log(a)
    console.log("a.slice(5)  = "+ a.slice(5))
    console.log("a.slice(5,10)  = "+ a.slice(5,10))
    console.log("a.slice(-8)  = "+ a.slice(-8))

    console.log("a.slice(-10,-2)  = "+ a.slice(-10,-2))
    console.log("a.slice()  = "+ a.slice())
    
    a="          hey i m in this   string            "
    console.log("a.trim = "+ a.trim())  
    
}


function fun2()
{
    ob = new Object();
    ob.id=111
    ob.name = "shilpa"
    ob.marks=99

    console.log(ob.id +" " + ob.name + " " + ob.marks)


    ob1 = {id:666,name:"shyam",marks:88}
    console.log(ob1.id +" " + ob1.name + " " + ob1.marks)

}

function fun3()
{
    console.log(" Math.abs(-77.8) = " + Math.abs(-77.8))
    
    console.log(" Math.ceil(-7.2) = " + Math.ceil(-7.2))
    console.log(" Math.ceil(7.2) = " + Math.ceil(7.2))

    console.log(" Math.floor(-7.2) = " + Math.floor(-7.2))
    console.log(" Math.floor(7.2) = " + Math.floor(7.2))

    

    console.log(" Math.round(-7.2) = " + Math.round(-7.2))
    console.log(" Math.round(7.2) = " + Math.round(7.2))

    console.log(" Math.cbrt(27) = " + Math.cbrt(27))
    console.log(" Math.sqrt(9) = " + Math.sqrt(9))
    
    
    console.log(" Math.pow(2,6) = " + Math.pow(2,6))
    console.log(" Math.max(2,6,44,5,7,88) = " + Math.max(2,6,44,5,7,88))
    console.log(" Math.min(2,6,5,3,88,9) = " + Math.min(2,6,5,3,88,9))
    

    
    
}









