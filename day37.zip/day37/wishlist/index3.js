function addwish()
{
    var data = document.getElementById("myinput").value;

    if(data=='')
    {
        alert("Please make a wish")
    }
    else
    {
        var ul = document.getElementById("wishlist");
        var li = document.createElement("li");
        var wish=document.createTextNode(data);
        
        var span = document.createElement("span");
        var txt = document.createTextNode("\u00D7");
        span.className="close";
        span.appendChild(txt);

        li.appendChild(wish);
        li.appendChild(span);
        ul.appendChild(li);

        close = document.getElementsByClassName("close");
        for(i=0;i<close.length;i++)
        {
            close[i].onclick = function(){
                var div=this.parentElement;
                div.style.display = "none";
            }
        }
    }
    document.getElementById("myinput").value='';  
}